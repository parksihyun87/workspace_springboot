package com.demo_todo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoTodoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoTodoApplication.class, args);
    }

}
