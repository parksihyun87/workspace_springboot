package com.demo_todo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoTodoApplicationTests {

    @Test
    void contextLoads() {
    }

}
